var attempt = 3; // Variable to count number of attempts.
// Below function Executes on click of login button.
function validate(){
	const obj = JSON.parse(user);
	var success = false;
	//document.getElementById("demo").innerHTML = obj[1].ID + ", " + obj[1].uname;
	var usern = document.getElementById("username").value;
	var passw = document.getElementById("password").value;
	var i;
	
	for(i in obj){
	 // alert("In Looop"+obj[i].uname);
	  if((obj[i].uname == usern) && (obj[i].pword == passw))
	  {
		success = true;
		break;
	  }
	  else
         success = false;    	  
	}
	if(success)
	{
		alert("Welcome  "+usern + " You are successfully verified");
		window.location = "index.html";
	}
	else{
		attempt --;// Decrementing by one.
		alert("You have left "+attempt+" attempt;");
		// Disabling fields after 3 attempts.
		//document.getElementById("demo2").innerHTML = "UnSuccessfull";
	}
	if( attempt == 0){
		document.getElementById("username").disabled = true;
		document.getElementById("password").disabled = true;
		document.getElementById("submit").disabled = true;
		document.getElementById("info").innerHTML = "Please check the usernames and passwords in the json file";
		return false;
	}
}
//function for calculator
function calculate() {
    const inputField = document.getElementById('input');
    const resultField = document.getElementById('result');
    
    const expression = inputField.value;
    let result = '';

    try {
        result = eval(expression); // Using eval to calculate the expression (Note: Eval can be unsafe in some situations).
    } catch (error) {
        result = 'Error: Invalid expression';
    }

    resultField.textContent = result;
}

//Custom alert box
document.getElementById('custom-alert').addEventListener('click', function () {
    document.getElementById('alert-box').style.display = 'block';
  });
  
  document.getElementById('close-alert').addEventListener('click', function () {
    document.getElementById('alert-box').style.display = 'none';
  });
  